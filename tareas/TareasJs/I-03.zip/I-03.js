/* 03.01 */

var meses = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
for(let i=0; i<meses.length; i++){
    alert(meses[i]);
}

/* 03.02 */

var nombre = [];
for(let i=0; i<3; i++){
    var nom = prompt();
    nombre[i] = nom;
}
for(let i=0; i<3; i++){
    alert(nombre[i]);
}

/* 03.03 */

var clasificaciones = ["Ane", "Ohian", "Jon", "Zuri", "Maria", "Antton"];
for(let i=0; i<clasificaciones.length; i++){
    alert(clasificaciones[i]);
}
clasificaciones = ["Mariana","Eneko","Amaia","Ane","Ohian","Zuri","Jon","Maria"]
for(let i=0; i<clasificaciones.length; i++){
    alert(clasificaciones[i]);
}