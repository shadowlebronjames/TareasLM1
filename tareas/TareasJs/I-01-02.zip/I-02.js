/* 02.01 */

alert("Hola Mundo!\nMira que facil es utilizar 'comillas simples' y \"comillas dobles\"\n(mentira)");

/* 02.02*/

var culo = prompt("Como te llamas?");
alert("Hola "+culo+", bienvenido a tu web");

/* 02.03 */

function edad(){
    var edad = prompt("Solicito tu edad, "+culo);
    alert("Gracias por la respuesta");
    document.getElementById("txtedad").innerHTML = "Tienes "+edad+" años";
}

/* 02.04 */

var numeroEntero = 1625;
alert("El valor de la variable número entero es "+numeroEntero);
numeroEntero = 375;
alert(numeroEntero+125);

/* 02.05 */

var palabraTexto = "casa";
alert(palabraTexto);
/* Ejecuta y mira si es correcto */
var palabraTextoLarga = "Hola, que tal, buenos dias, hoy me encuentro con energia para intentar correr."
alert(palabraTextoLarga);